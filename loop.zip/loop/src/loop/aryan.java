package loop;

public class aryan {

	public static void main(String[] args) {
		if (int i=0; i<=10; i++){
			
		}

	}

}
