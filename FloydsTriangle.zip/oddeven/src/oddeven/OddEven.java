package oddeven;

public class OddEven {

	public static void main(String[] args) {
		int[] number=new int[]{12,13,47,3,4,45,73,};
		
		for(int i=0; i<number.length; i++){
			if(number[i]%2==0)
				System.out.println(number[i] + "Even number.");
			else
				System.out.println(number[i] + "Odd number.");
		}
		
			

	}

}
